import logo from './logo.svg';
import React from 'react';
import Login from './Login';
import DeptList from './DeptList';

function App() {
  // Scalar Variables
  let uname = "Scott";
  let age = 25;
  let email = "scott@gmai.com";

  // Array
  let citiesArray = ["Hyderabad", "Mumbai", "Pune", "Chennai", "Goa"];

  // Object
  let deptObj = { deptno: 10, dname: "Accounts", loc: "Hyd" };

  // Array of Objects
  let deptsArray = [
    { deptno: 10, dname: "Accounts", loc: "Hyd" },
    { deptno: 20, dname: "Sales", loc: "Pune" },
    { deptno: 30, dname: "Marketing", loc: "Hyd" },
    { deptno: 40, dname: "Operations", loc: "Chnnai" },
  ];


  let resultArray1 = citiesArray.map((item) => {
    return <li>{item}</li>
  });

  let resultArray2 = deptsArray.map((item) => {
    return <tr>
      <td>   {item.deptno}  </td>
      <td>   {item.dname}  </td>
      <td>   {item.loc}  </td>
    </tr>
  });


  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />

      <div>
        <h3>Scalar Data</h3>
        User Name :   {uname}    <br />
        User Age :   {age}    <br />
        User Email  :   {email}    <br />
      </div>
      <hr />

      <div>
        <h3>Array of Strings</h3>

        <ul>
          {resultArray1}
        </ul>
      </div>
      <hr />
      <div>
        <h3>Single Object</h3>
        Dept Number  :   {deptObj.deptno}    <br />
        Dept Name  :     {deptObj.dname}    <br />
        Dept Location  : {deptObj.loc}    <br />
      </div>
      <hr />


      <div>
        <h3>Array of Objects</h3>

        <table border="2" width="400" cellspacing="0" cellpadding="5">

          <tr>
            <th>Dept Number</th>
            <th>Dept Name</th>
            <th>Location</th>
          </tr>

          {resultArray2}
        </table>

      </div>


    </>
  );
}

export default App;
