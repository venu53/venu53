import React from 'react';
import DeptList from './DeptList';

function App() {
  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />

       <DeptList />
    </>
  );
}

export default App;
