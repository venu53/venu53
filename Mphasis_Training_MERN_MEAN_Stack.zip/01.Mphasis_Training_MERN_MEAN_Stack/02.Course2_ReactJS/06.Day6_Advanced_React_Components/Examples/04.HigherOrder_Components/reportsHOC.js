import axios from "axios";
import { useEffect, useState } from "react";


export function reportsHOC(InputComponent, inputData) {

    let  NewComponent =   function(props) 
    {
       let [data, setData] = useState([]);    
       let [columns, setColumns] = useState([]);
       let headers = inputData.header;
      
       // 1. Get the data from the given url 
      useEffect( () => 
      {
        axios.get(inputData.url)      
        .then(
          (result) => {
            setData(result.data);
  
            let keysArray =  Object.keys(result.data[0]);
            keysArray = keysArray.filter(item => item != "id");
            setColumns(keysArray);
            console.log(result.data);
          }
        );
      }, []);
  
        // 2.   Generate the data as table format
        return (
          <div> 
              <h2>{headers}</h2>
  
              <table border="2" cellSpacing="0">
                <thead>
                  <tr>
                  {columns.map(c => <th>{c.toUpperCase()}</th>)}
                  </tr>
                </thead>
  
                <tbody>
                {data.map(item => (
                  <tr>
                      {columns.map(col => <td>{item[col]}</td>)}
                    </tr>
                ))}
                </tbody>
              </table>
        </div>
        );
  
      };
  
      return NewComponent;
  }
   
  