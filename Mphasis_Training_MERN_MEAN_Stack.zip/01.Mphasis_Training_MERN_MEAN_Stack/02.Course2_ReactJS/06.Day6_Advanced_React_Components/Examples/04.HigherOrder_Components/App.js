import { reportsHOC } from './reportsHOC';


const EmployeeComponent=reportsHOC(null,
  {	url:'http://localhost:3500/emps',	 
     header:'Employee Data'});

const DepartmentComponent=reportsHOC(null,
      {	url:'http://localhost:4500/depts',        
        header:'Department Data'});

const CustomersComponent=reportsHOC(null,
          {	url:'http://localhost:5500/customers',        
            header:'Customers Data'});

function App(){ 
    return (
      <div>  
          <EmployeeComponent />
          <hr/>
          <DepartmentComponent />
          <hr/>
          <CustomersComponent />
      </div>
    );   
}

export default App;
