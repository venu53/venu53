console.clear(); 
 
 let   deptObj = {  deptno : 10,  dname  : "Accounts", loc : "Hyd"  };		
 
		//	console.log(deptObj.deptno);
		//	console.log(deptObj["deptno"]);	
			
		let arr =  Object.values(deptObj);
		
		for(let item of arr)
		{
			console.log(item);
		}
console.log("-------------------------------------------------------------------");

		
	
	let deptsArray =   [
            { deptno: 10, dname: "Accounts", loc: "Hyd" },
            { deptno: 20, dname: "Sales", loc: "Pune" },
            { deptno: 30, dname: "Marketing", loc: "Hyd" },
            { deptno: 40, dname: "Operations", loc: "Chennai" },
        ];
		
		
		/*
		for(let  obj  of deptsArray  )
		{
			let arr2 =  Object.values(obj);		
			
			for(let item of arr2)
			{
				console.log(item);
			}
		}
		*/
		
		for(let  obj  of deptsArray  )
		{
			let keysArray =  Object.keys(obj);					
			
			for(let key of keysArray)
			{
				console.log(` Key :  ${key},  Value :  ${obj[key]}` );
			}
		}

		
		
 
 
		
 