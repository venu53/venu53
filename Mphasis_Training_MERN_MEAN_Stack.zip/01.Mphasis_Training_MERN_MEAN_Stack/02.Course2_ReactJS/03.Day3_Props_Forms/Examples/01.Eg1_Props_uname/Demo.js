function Demo(props)
{
    //  console.log(props.uname);
    // props.uname = "Scott";  // error. it is read-only

    return(
        <>
            <h3 style={ {"border":"2px solid black", "padding":"10px", "color":"blue", "margin" : "10px" } }>
                    Hi {props.uname}, Good morning...!
            </h3>
        </>
    );
}


export default Demo;