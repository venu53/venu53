import React from 'react';
import DeptList from './DeptList';
import UserList from './UserList';
import Demo from './Demo';

function App() {  

  let strUser1 = "Scott";
  let strUser2 = "Smith";

  let usersArray = ["Ravi", "Ragu", "Ramu"];


  let resultsArray =  usersArray.map( (item) =>
  {
     return <Demo uname={item} /> 
  });

  return (
    <> 
       <Demo  uname="Narasimha" />
       <hr/>
       <Demo  uname={strUser1} />
       <Demo  uname={strUser2} />
       <hr/>
       {resultsArray}

    </>
  );
}

export default App;
