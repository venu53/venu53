import { configure } from "@testing-library/react";
import { useState } from "react";
import SummaryRow from "./SummaryRow";

function DeptList() {

    const [deptsArray, setDeptsArray] = useState([]);

 

    function getDeptsButton_click() {
        let tempArray = [
            { deptno: 10, dname: "Accounts", loc: "Hyd" },
            { deptno: 20, dname: "Sales", loc: "Pune" },
            { deptno: 30, dname: "Marketing", loc: "Hyd" },
            { deptno: 40, dname: "Operations", loc: "Chennai" },
        ];

        setDeptsArray(tempArray);
    }

 
 
 

    function deleteDept_click(dno) {

        let flag = window.confirm("Are you sure want to delete?");    
        if(  flag == false   )
        {
            return;
        }

        let tempArray = [...deptsArray];    // cloning original array into temp array
        let index = tempArray.findIndex(item => item.deptno == dno);
        tempArray.splice(index, 1);
        setDeptsArray(tempArray);
    }

 

    let resultArray2 = deptsArray.map((item, index) => {
        return <tr  className={ (index % 2 == 0?'table-success':'table-danger') }>
            <td>   {item.deptno}  </td>
            <td>   {item.dname}  </td>
            <td>   {item.loc}  </td>
            <td>
                <a href="javascript:void(0);" 
                   onClick={() => deleteDept_click(item.deptno)}>
                    <img  src="images/delete.png"  width="20"  />
                </a>   
            </td>
        </tr>
    });

    return (
        <>
            <h3>Conditional Rendering in React Views</h3>
            <hr />

           
            <input type="button" className="btn btn-primary" onClick={getDeptsButton_click} value="Get Depts" />
             <hr />

            <table className="table" border="2" width="400" cellspacing="0" cellpadding="5">
                <tr className="table-primary">
                    <th>Dept Number</th>
                    <th>Dept Name</th>
                    <th>Location</th>
                    <th></th>
                </tr>
                {resultArray2}


                <SummaryRow  deptsCount={deptsArray.length} />


                {/* 
                
                {  ( deptsArray.length == 0? 
                    <tr>
                     <td align="center" colspan="4" style={{"color":"red"}}>
                        **No Departments are available
                      </td>
                    </tr>
                :"") } 
                
                */}


                {/*                 
                <tr>
                     <td align="center" colspan="4" style={{"color":"red"}}>
                     { (deptsArray.length == 0)? "**No Departments are available":"" }
                      </td>
                </tr>                
                */}

            </table>
        </>
    );
}

export default DeptList;