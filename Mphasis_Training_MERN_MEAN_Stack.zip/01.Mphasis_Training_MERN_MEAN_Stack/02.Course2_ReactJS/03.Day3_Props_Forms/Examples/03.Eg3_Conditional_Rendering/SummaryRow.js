function SummaryRow(props)    {
    if(props.deptsCount == 0)     {
        return (
            <tr>
            <td align="center" colspan="4" style={{"color":"red"}}>
               **No Departments are available
             </td>
           </tr>
      );
    }
    else    
    {
      return (<></>);
    }
}

export default SummaryRow;
