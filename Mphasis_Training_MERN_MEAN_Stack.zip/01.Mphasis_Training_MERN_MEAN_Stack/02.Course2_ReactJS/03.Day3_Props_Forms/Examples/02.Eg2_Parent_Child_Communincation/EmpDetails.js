function EmpDetails(props)
{ 
    function deleteClick_child()
    {
       // alert("Hello from Child component");
        props.onDeleteClick( props.empObj.empno );
    }

    return(
        <div style={{"float":"left"}}> 
            <div style={ {border : "2px solid blue", padding :  "1px",  margin :  "2px",borderTopWidth :  "20px", borderRadius :  "10px", width : "250px"} }>
                <h4 align="center"> {props.empObj.empno} - {props.empObj.ename}  </h4>           
                <span> Employee Job  :  {props.empObj.job}  </span> <br/>
                <span> Employee Deptno  :  {props.empObj.deptno}  </span> <br/> 
                <hr/>
                <p style={{"textAlign" : "center", "margin" : "0px"}}>
                    <a href="javascript:void(0);" onClick={deleteClick_child}>
                        <img  src="images/delete.png"  width="20"  />
                    </a>
                </p>
                
            </div>
        </div>
    );
}


export default EmpDetails;