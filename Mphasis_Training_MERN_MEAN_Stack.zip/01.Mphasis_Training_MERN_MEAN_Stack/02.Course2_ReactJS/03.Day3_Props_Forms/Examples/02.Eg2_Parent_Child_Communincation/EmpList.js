import { useState } from "react";
import EmpDetails from "./EmpDetails";

function EmpList()
{
    let  empData =  [
        {  empno : 10256, ename:"Scott", job: "Manager", deptno : 10  },
        {  empno : 10257, ename:"Smith", job: "Lead", deptno : 20  },
        {  empno : 10258, ename:"Sandy", job: "Programmer", deptno : 30  },
        {  empno : 10259, ename:"Sam", job: "Tester", deptno : 40  },
        {  empno : 10260, ename:"Scott", job: "Manager", deptno : 10  },
        {  empno : 10261, ename:"Smith", job: "Lead", deptno : 20  },
        {  empno : 10262, ename:"Sandy", job: "Programmer", deptno : 30  },
        {  empno : 10263, ename:"Sam", job: "Tester", deptno : 40  } 
    ];

    const [empsArray, setEmpsArray] = useState(empData);


    function deleteClick_parent( eno )
    {
        let tempArray = [...empsArray];   
        let index = tempArray.findIndex(item => item.empno == eno);
        tempArray.splice(index, 1);
        setEmpsArray(tempArray);
    }

    let resultArray =  empsArray.map( (item) =>
    {
        return <EmpDetails  onDeleteClick={deleteClick_parent}  empObj={ item }  />;
    });

    return (
        <>
                {resultArray}          
        </>
    );
}

export default EmpList;