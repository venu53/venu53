import React from "react";

export class Login extends React.Component {

    constructor(props)
    {
        super(props);
        this.state = { uname: "", password  : "",  result : "" };
        this.textChange = this.textChange.bind(this);
        this.buttonClick = this.buttonClick.bind(this) ; 
    }    


    textChange(e)
    {
        this.setState( { [e.target.name] :  e.target.value} );
    }

    buttonClick() {
        if (this.state.uname == "admin" && this.state.password == "admin123") {
            this.setState({ result :  "Welcome to Admin"});
        }
        else {
            this.setState({ result :  "Invalid User Id or Password"});
        }
    }

    render() {
        return (
        <div style={ {"backgroundColor" : this.props.bgcolor} }> 
            <h3>Working with Class Components -- Login</h3>
            <hr />

            <fieldset>
                <legend>User Login</legend>
                User Name : <input type="text" name="uname"  onChange={this.textChange} />
                <br /> <br />

                Password : <input type="password" name="password"  onChange={this.textChange}/>
                <br /> <br />

                <input type="button" onClick={this.buttonClick} value="Get Message" />
                <p>{this.state.result}</p>
            </fieldset>
        </div>);            
    }
}