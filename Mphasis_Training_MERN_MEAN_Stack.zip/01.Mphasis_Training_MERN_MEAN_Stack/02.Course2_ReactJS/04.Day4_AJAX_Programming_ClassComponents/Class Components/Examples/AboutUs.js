import React from "react";

export class AboutUs extends React.Component {
    render() {
        return <>
            <h3>Working with Class Components</h3>
            <hr />
            <h3>This is About Us </h3>
            <p>This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. </p>
            <p>This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. This page provides details about our compnay. </p>
        </>;
    }
}