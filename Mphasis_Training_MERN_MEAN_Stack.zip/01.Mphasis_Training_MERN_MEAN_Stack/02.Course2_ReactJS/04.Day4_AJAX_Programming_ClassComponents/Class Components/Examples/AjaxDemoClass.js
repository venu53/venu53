import axios from "axios";
import React from "react";

export class AjaxDemoClass extends React.Component {

    constructor(props) {
        super(props);
        this.state = { customersArray: [] };
        this.getDataButton_click = this.getDataButton_click.bind(this);
    }

    getDataButton_click() {
        let url = "https://www.w3schools.com/angular/customers.php";
        axios.get(url).then((resData) => {
            this.setState({ customersArray: resData.data.records });
        });
    }   

    render() {

        let resultArray = this.state.customersArray.map(item => {
            return <tr>
                <td>{item.Name}</td>
                <td>{item.City}</td>
                <td>{item.Country}</td>
            </tr>;
        });

        return <>
            <h3>Working with Class Components -- Login</h3>
            <hr />
            <h3>AJAX Programming in React JS using Axios Package</h3>
            <hr/>

            <input type="button" onClick={this.getDataButton_click}
                value="Get Data" />

            <hr />

            <table border="2" cellSpacing="0" width="500">
                <tr>
                    <th>Customer Name</th>
                    <th>City</th>
                    <th> Country</th>
                </tr>
                {resultArray}
            </table>

        </>;
    }
}