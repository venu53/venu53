import React from 'react'; 
import AjaxDemo1 from './AjaxDemo1';
import AjaxDemo2 from './AjaxDemo2';
import AjaxDemo3 from './AjaxDemo3';

function App() {   
  return (
    <> 
      <AjaxDemo3 />
    </>
  );
}

export default App;
