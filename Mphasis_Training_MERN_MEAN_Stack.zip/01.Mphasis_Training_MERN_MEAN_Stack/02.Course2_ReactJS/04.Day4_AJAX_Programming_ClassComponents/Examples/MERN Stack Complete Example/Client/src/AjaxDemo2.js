import axios from 'axios';
import { useState } from 'react';

function AjaxDemo2() {   

   const [deptsArray, setDeptsArray] = useState([]);


  function getDataButton_click() {

      let url = "http://localhost:4100/depts";
      axios.get(url).then( (resData) => 
      {       
        setDeptsArray(resData.data);
      });
  }


  let resultArray = deptsArray.map(item => 
    {
      return <tr>
          <td>{item.deptno}</td>
          <td>{item.dname}</td>
          <td>{item.loc}</td>
      </tr>;
    });


  return (
    <div style={{"padding":"5px"}}> 

      <h3>AJAX Programming in React JS using Axios Package (JSON Server)</h3>
      <hr/>


      <input type="button" onClick={getDataButton_click} 
               value="Get Data" />

      <hr/>

      <table  border="2" cellSpacing="0" width="500">
          <tr>
            <th>Dept Number</th>
            <th>Dept Name</th>
            <th>Dept Location</th>
          </tr>
          {resultArray} 
      </table>         

    </div>
  );
}

export default AjaxDemo2;
