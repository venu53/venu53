import axios from 'axios';
import { useState } from 'react';

function AjaxDemo1() {   

   const [customersArray, setCustomersArray] = useState([]);


  function getDataButton_click() {

      let url = "https://www.w3schools.com/angular/customers.php";
      axios.get(url).then( (resData) => 
      {
        console.log(resData.data.records);
        setCustomersArray(resData.data.records);
      });
  }


  let resultArray = customersArray.map(item => 
    {
      return <tr>
          <td>{item.Name}</td>
          <td>{item.City}</td>
          <td>{item.Country}</td>
      </tr>;
    });


  return (
    <div style={{"padding":"5px"}}> 

      <h3>AJAX Programming in React JS using Axios Package</h3>
      <hr/>


      <input type="button" onClick={getDataButton_click} 
               value="Get Data" />

      <hr/>

      <table  border="2" cellSpacing="0" width="500">
          <tr>
            <th>Customer Name</th>
            <th>City</th>
            <th> Country</th>
          </tr>
          {resultArray} 
      </table>         

    </div>
  );
}

export default AjaxDemo1;
