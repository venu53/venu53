import { useState } from "react";

function Login()
{
    const [uname, setUname] = useState("Scott");
    const [count, setCount] = useState(0);


    function buttonClick()
    {
        setUname("Smith");  // Internally it reflects the uname variable
        setCount(count + 1);
    }

    return (
        <>
            <h3>Event Handling in React JS</h3>
            <hr/>
            <input type="button" onClick={buttonClick} value="Get Message"  />
            <h3>Hi {uname}, Good morning...!</h3>
            <h3>Count :  {count}</h3>
        </>
    );
}

export default Login;