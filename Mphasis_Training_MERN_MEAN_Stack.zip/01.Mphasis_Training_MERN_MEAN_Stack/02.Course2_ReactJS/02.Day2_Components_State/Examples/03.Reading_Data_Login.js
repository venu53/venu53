import { useState } from "react";

function Login() {
    const [uname, setUname] = useState("");
    const [password, setPassword] = useState("");
    const [result, setResult] = useState("");


    function  handleUnameChange(event)
    {        
        setUname(event.target.value);
    }

    function  handlePasswordChange(event)
    {        
        setPassword(event.target.value);
    }


    function buttonClick() {
        if (uname == "admin" && password == "admin123") {
            setResult("Welcome to Admin");
        }
        else {
            setResult("Invalid User Id or Password");
        }

    }

    return (
        <>
            <h3>Event Handling in React JS</h3>
            <hr />
            <fieldset>
                <legend>User Login</legend>
                User Name : <input type="text"  onChange={handleUnameChange} />
                <br /> <br />

                Password : <input type="password"  onChange={handlePasswordChange}/>
                <br /> <br />

                <input type="button" onClick={buttonClick} value="Get Message" />
                <p>{result}</p>
            </fieldset>
        </>
    );
}

export default Login;