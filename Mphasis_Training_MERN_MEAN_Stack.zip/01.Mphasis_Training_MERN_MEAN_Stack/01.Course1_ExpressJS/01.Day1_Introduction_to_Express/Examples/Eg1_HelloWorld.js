var express = require("express");

var app =  express();   // Creates an express application

app.get("/", function(req, res){
    res.send("<h1 align='center'>Web Application Development using Express JS</h1>");
});

var server = app.listen(3005, function(){});
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");