var express = require("express");

var app =  express();   // Creates an express application

app.get("/", function(req, res){

    let str = "<h3 align='center'>Welcome to Express JS Applications</h3>";   
    str +=   "<hr/>";
    str +=   "<div style='color:blue;'>";
    str +=   "User Name  :  Narasimha Rao <br/>";
    str +=   "User Age  :  25 <br/>";
    str +=   "User E-mail  :  tnrao.trainer@gmail.com <br/>";
    str +=   "</div>";

    res.send(str);
});

var server = app.listen(3005, function(){});
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");