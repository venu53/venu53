var express = require("express");

var app =  express();   // Creates an express application

app.get("/", function(req, res){

    let uname = "Scott";
	let age = 25;
	let email = "scott@gmail.com";

    let str = "<h3 align='center'>Welcome to Express JS Applications</h3>";   
    str +=   "<hr/>";

    str +=   `<div  style="border:1px solid gray; border-top-width: 20px; padding:5px; width:300px; border-radius:10px;">
                User Name :  ${uname}  <br/>
                User Age :  ${age}  <br/>
                User Email :  ${email}  <br/>
             </div>`  ;

    res.send(str);
});

var server = app.listen(3005, function(){});
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");