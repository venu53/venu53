var express = require("express");
var bodyParser = require("body-parser");  // npm i body-parser

// Creates an express application
var app = express();   

// Confgiure the middleware
app.use(bodyParser.urlencoded({extended : false}));

app.set("view engine", "ejs");

app.get("/", function (req, res) {   
    res.render("home", {});
});

app.get("/Login", function (req, res) {       
    res.render("login", { errorMessage : "" });
});

app.post("/Login", function (req, res) {   
    
    let uid = req.body.t1;
    let pwd = req.body.t2;

    if(uid == "admin" && pwd == "admin123")
    {       
        res.redirect("/");  // Redirect from one route to another route
    }
    else
    {   res.render("login", { errorMessage : "Invalid uid or password."  });
    }   
});



var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");