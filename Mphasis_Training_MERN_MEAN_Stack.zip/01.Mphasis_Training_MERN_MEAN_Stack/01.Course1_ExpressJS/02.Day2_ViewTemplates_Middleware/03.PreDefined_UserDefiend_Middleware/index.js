var express = require("express");
var bodyParser = require("body-parser");  // npm i body-parser

// Creates an express application
var app = express();   

// Configure the middleware
app.use(bodyParser.urlencoded({extended : false}));

// User-defined middleware
app.use((req, res, next)=>{
    let dateObj = new Date();
    console.log(`Request Time : ${dateObj.getHours()}:${dateObj.getMinutes()}:${dateObj.getSeconds()}`);
    console.log("Request Url  : " + req.url);     
    next();
});


app.set("view engine", "ejs");

app.get("/", function (req, res) {   
    res.render("home", {});
});

app.get("/Login", function (req, res) {       
    res.render("login", { errorMessage : "" });
});

app.post("/Login", function (req, res) {   
    
    let uid = req.body.t1;
    let pwd = req.body.t2;

    if(uid == "admin" && pwd == "admin123")
    {       
        res.redirect("/");  // Redirect from one route to another route
    }
    else
    {   res.render("login", { errorMessage : "Invalid uid or password."  });
    }   
});



var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");