var express = require("express");

var app = express();   // Creates an express application

app.set("view engine", "pug");

app.get("/", function (req, res) {

    let dataObj = {};
    dataObj.uname = "Scott";
    dataObj.age = 25;
    dataObj.email = "scott@gmai.com";

    dataObj.citiesArray = ["Hyderabad", "Mumbai", "Pune", "Chennai", "Goa"];

    dataObj.deptObj = { deptno: 10, dname: "Accounts", loc: "Hyd" };

   
    res.render("home", dataObj);
});

var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");