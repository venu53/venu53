const express = require("express");
const bodyParser = require("body-parser");  
const userRouter = require('./user-routes');
const deptsRouter = require('./depts-routes');
const cookieParser = require('cookie-parser')

// Creates an express application
var app = express();   

app.use(bodyParser.urlencoded({extended : false})); 
app.use(cookieParser())

// app.use(userRouter);
app.use("/user", userRouter);
app.use("/depts", deptsRouter);
 
// Confgiure the middleware
app.set("view engine", "ejs");

app.get("/", function (req, res) {   
    //console.log(req.cookies);
    let uname = req.cookies.uname;  // Reading data from cookie

    if(uname == "" || uname == undefined || uname == null)
    {
        uname = "Guest User";
    }

    res.render("home", {uname});
});


var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");